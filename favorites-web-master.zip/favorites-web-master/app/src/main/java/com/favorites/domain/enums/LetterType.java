package com.favorites.domain.enums;

/**
 * Created by DingYS on 2017/3/7.
 */
public enum LetterType {

    ORIGINAL,REPLY

}
