/*
 Navicat Premium Data Transfer

 Source Server         : 47.98.158.124
 Source Server Type    : MySQL
 Source Server Version : 50732
 Source Host           : 47.98.158.124:3306
 Source Schema         : favorites

 Target Server Type    : MySQL
 Target Server Version : 50732
 File Encoding         : 65001

 Date: 08/04/2021 16:44:17
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for collect
-- ----------------------------
DROP TABLE IF EXISTS `collect`;
CREATE TABLE `collect` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `category` varchar(255) DEFAULT NULL,
  `charset` varchar(255) DEFAULT NULL,
  `create_time` bigint(20) NOT NULL,
  `description` text,
  `favorites_id` bigint(20) NOT NULL,
  `is_delete` varchar(255) DEFAULT NULL,
  `last_modify_time` bigint(20) NOT NULL,
  `logo_url` varchar(300) DEFAULT NULL,
  `remark` varchar(255) DEFAULT NULL,
  `title` varchar(255) NOT NULL,
  `type` varchar(255) DEFAULT NULL,
  `url` varchar(600) NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `collect_time` bigint(20) DEFAULT NULL,
  `new_favorites` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=56 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of collect
-- ----------------------------
BEGIN;
INSERT INTO `collect` VALUES (43, NULL, 'UTF-8', 1617006085701, 'This free online PDF to DOC converter allows you to convert a PDF document to Microsoft Word DOC format%2C providing better quality than many other converters.', 6, 'NO', 1617006085701, 'img/logo.jpg', 'pdf', 'PDF to DOC – Convert PDF to Word Online', 'PUBLIC', 'https://pdf2doc.com/', 37, NULL, '');
INSERT INTO `collect` VALUES (44, NULL, 'UTF-8', 1617006126235, '删除本地分支： 1.查看本地分支列表 git branch 2.删除本地分支 git branch -d 分支名称 删除远程分支： 1.查看远程分支列表 git branch -a 2.删除远程分支 ', 7, 'NO', 1617006126235, 'img/logo.jpg', 'git', 'git删除本地分支和远程分支 - 奔跑的小龙码 - 博客园', 'PUBLIC', 'https://www.cnblogs.com/lwcode6/p/11084537.html', 37, NULL, '');
INSERT INTO `collect` VALUES (45, NULL, 'UTF-8', 1617006217642, '下载地址https%3A%2F%2Farchive.apache.org%2Fdist%2Fpoi%2Frelease%2Fbin%2F需要的jar包（我用的是3.10final）Poi-3.10-Final.jar （用于xls）Poi-ooxml-3.10-Final.jar （用于xlsx）Poi-ooxml-schemas-3.10.jarXmlbeans-2.30.jardom4j-1.6.1.jarp', 8, 'NO', 1617006217642, 'img/logo.jpg', 'POI', 'JAVA POI的使用_林中静月下仙的博客-CSDN博客_poi', 'PUBLIC', 'https://blog.csdn.net/qq_21137441/article/details/79226171', 37, NULL, '测试哦~');
INSERT INTO `collect` VALUES (46, NULL, 'UTF-8', 1617006679645, '假如我们有一段json串，该json串是由一系列结构相同的数据集合组成，现在有一个需求，需要将json集合转换成excel表单。', 8, 'NO', 1617006679645, 'img/logo.jpg', 'json', 'Json字符串转excel表格文件_[|行远自迩，登高自卑-CSDN博客_json字符串转excel', 'PUBLIC', 'https://changle.blog.csdn.net/article/details/76468354', 37, NULL, '');
INSERT INTO `collect` VALUES (47, NULL, 'UTF-8', 1617006812309, 'MySQL索引原理及慢查询优化 - 美团技术团队', 8, 'NO', 1617006815548, 'img/logo.jpg', 'mysql', 'MySQL索引原理及慢查询优化 - 美团技术团队', 'PUBLIC', 'https://tech.meituan.com/2014/06/30/mysql-index.html', 37, NULL, '');
INSERT INTO `collect` VALUES (48, NULL, 'UTF-8', 1617007446557, '1. 下载该插件，地址：https%3A%2F%2Fgithub.com%2Fliufengji%2Fes head%2Fblob%2Fmaster%2Felasticsearch head.crx 下载后的文件名是：elastic', 9, 'NO', 1617007446557, 'img/logo.jpg', '谷歌', '谷歌浏览器安装Elasticsearch-head 插件 - 三度 - 博客园', 'PUBLIC', 'https://www.cnblogs.com/sanduzxcvbnm/p/12014887.html', 37, NULL, '');
INSERT INTO `collect` VALUES (49, NULL, 'UTF-8', 1617008891190, '一、校验数字的表达式  数字：^[0-9]*%24    n位的数字：^\\d{n}%24  至少n位的数字：^\\d{n%2C}%24  m-n位的数字：^\\d{m%2Cn}%24  零和非零开头的数字：^(0|[1-9][0-9]*)%24  非零开头的最多带两位小数的数字：^([1-9][0-9]*)%2B(\\.[0-9]{1%2C2})%3F%24  带1-2位小数的正数或负数：^(\\-)%3F\\d%2B(\\.\\d{1%2C2})%24  正数、负数、和小数：^(\\-|\\%2B)%3F\\d%2B(\\.\\..', 7, 'NO', 1617008891190, 'img/logo.jpg', '正则', '正则表达式在线测试 | 菜鸟工具', 'PUBLIC', 'https://c.runoob.com/front-end/854', 37, NULL, '');
INSERT INTO `collect` VALUES (50, NULL, 'UTF-8', 1617008916526, 'DES 加密、解密在线工具免费。支持模式有：ECB、CBC、CTR、CFB和CFB。输出可以是BASE64、十六进制或文本。该工具检测解密结果并设置其格式，如 JSON。', 8, 'NO', 1617008916526, 'img/logo.jpg', 'DES', 'DES在线解密 DES在线加密 des hex - The X 在线工具', 'PUBLIC', 'https://the-x.cn/cryptography/des.aspx', 37, NULL, '');
INSERT INTO `collect` VALUES (51, NULL, 'UTF-8', 1617013339912, 'DES 加密、解密在线工具免费。支持模式有：ECB、CBC、CTR、CFB和CFB。输出可以是BASE64、十六进制或文本。该工具检测解密结果并设置其格式，如 JSON。', 11, 'NO', 1617013339912, 'https://the-x.cn/images/wxQRD.png', 'DES', 'DES在线解密 DES在线加密 des hex - The X 在线工具', 'PUBLIC', 'https://the-x.cn/cryptography/des.aspx', 38, NULL, NULL);
INSERT INTO `collect` VALUES (52, NULL, 'UTF-8', 1617013352396, '删除本地分支： 1.查看本地分支列表 git branch 2.删除本地分支 git branch -d 分支名称 删除远程分支： 1.查看远程分支列表 git branch -a 2.删除远程分支 ', 11, 'NO', 1617013352396, 'https://img2018.cnblogs.com/blog/1645656/201906/1645656-20190625182037895-294392568.png', 'git', 'git删除本地分支和远程分支 - 奔跑的小龙码 - 博客园', 'PUBLIC', 'https://www.cnblogs.com/lwcode6/p/11084537.html', 38, NULL, NULL);
INSERT INTO `collect` VALUES (53, NULL, 'UTF-8', 1617013367620, '为了更加合法合规运营网站，我们正在对全站内容进行审核，之前的内容审核通过后才能访问。 由于审核工作量巨大，完成审核还需要时间，我们正在想方设法提高审核速度，由此给您带来麻烦，请您谅解。 如果您访问园子', 11, 'NO', 1617013367620, 'img/logo.jpg', 'guvav', '非常抱歉，全站内容审核中... - 博客园团队 - 博客园', 'PUBLIC', 'https://www.cnblogs.com/cmt/p/14580194.html', 38, NULL, NULL);
INSERT INTO `collect` VALUES (54, NULL, 'UTF-8', 1617013379390, 'elasticsearch 5.0引入了一个新的客户端 RestClient ，使用HTTP API elasticsearch代替内部协议%2C RestClient 初始化方法是线程安全的，最理想的客户端生命周期是与应用相同，在应用停止服务之前应该关闭客户端链接，释放资源。    初始化客户端    RestClient restClient %3D RestClient.builder', 11, 'NO', 1617013379390, 'http://127.0.0.1:8080/img/logo.jpg', 'es', 'Elasticsearch系列(七)----JAVA客户端之RestClient操作详解_fendo-CSDN博客', 'PUBLIC', 'https://blog.csdn.net/u011781521/article/details/77853571', 38, NULL, NULL);
INSERT INTO `collect` VALUES (55, '', 'UTF-8', 1617099200976, '开课吧面向广大数字化专业和应用人才，提供Java、Web前端、数据分析、Python、人工智能、产品、设计、运营、智能物联等热门学科的体系化在线实战赋能和进阶课程，帮助用户实现职业提升、专业进阶和可持续成长。', 13, 'NO', 1617099200976, 'https://img.kaikeba.com/a/34035142900202dvoz.png', 'kaikeba', '开课吧-数字化人才在线教育平台', 'PUBLIC', 'https://www.kaikeba.com/', 40, NULL, NULL);
COMMIT;

-- ----------------------------
-- Table structure for collector_view
-- ----------------------------
DROP TABLE IF EXISTS `collector_view`;
CREATE TABLE `collector_view` (
  `id` bigint(20) NOT NULL,
  `counts` bigint(20) DEFAULT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of collector_view
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for comment
-- ----------------------------
DROP TABLE IF EXISTS `comment`;
CREATE TABLE `comment` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `collect_id` bigint(20) NOT NULL,
  `content` text NOT NULL,
  `create_time` bigint(20) NOT NULL,
  `reply_user_id` bigint(20) DEFAULT NULL,
  `user_id` bigint(20) NOT NULL,
  `is_delete` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of comment
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for config
-- ----------------------------
DROP TABLE IF EXISTS `config`;
CREATE TABLE `config` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `create_time` bigint(20) NOT NULL,
  `default_collect_type` varchar(255) NOT NULL,
  `default_favorties` varchar(255) NOT NULL,
  `default_model` varchar(255) NOT NULL,
  `last_modify_time` bigint(20) NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `collect_type_name` varchar(255) DEFAULT NULL,
  `model_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of config
-- ----------------------------
BEGIN;
INSERT INTO `config` VALUES (19, 1617006038747, 'public', '6', 'simple', 1617006038747, 37, NULL, NULL);
INSERT INTO `config` VALUES (20, 1617013311378, 'public', '10', 'simple', 1617013311378, 38, NULL, NULL);
INSERT INTO `config` VALUES (21, 1617093568324, 'public', '12', 'simple', 1617093568324, 39, NULL, NULL);
INSERT INTO `config` VALUES (22, 1617099158576, 'public', '13', 'simple', 1617099158576, 40, NULL, NULL);
COMMIT;

-- ----------------------------
-- Table structure for favorites
-- ----------------------------
DROP TABLE IF EXISTS `favorites`;
CREATE TABLE `favorites` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `count` bigint(20) NOT NULL,
  `create_time` bigint(20) NOT NULL,
  `last_modify_time` bigint(20) NOT NULL,
  `name` varchar(255) NOT NULL,
  `public_count` bigint(20) NOT NULL,
  `user_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of favorites
-- ----------------------------
BEGIN;
INSERT INTO `favorites` VALUES (6, 0, 1617006038634, 1617006038634, '未读列表', 10, 37);
INSERT INTO `favorites` VALUES (7, 2, 1617006105772, 1617008891423, '百万大人的收藏', 2, 37);
INSERT INTO `favorites` VALUES (8, 4, 1617006217524, 1617008916766, '测试哦~', 4, 37);
INSERT INTO `favorites` VALUES (9, 1, 1617007427617, 1617007446896, 'Echo', 1, 37);
INSERT INTO `favorites` VALUES (10, 0, 1617013311257, 1617013311257, '未读列表', 10, 38);
INSERT INTO `favorites` VALUES (11, 4, 1617013339880, 1617013379560, 'Echo的收藏夹', 4, 38);
INSERT INTO `favorites` VALUES (12, 0, 1617093568177, 1617093568177, '未读列表', 10, 39);
INSERT INTO `favorites` VALUES (13, 1, 1617099158430, 1617099201120, '未读列表', 1, 40);
COMMIT;

-- ----------------------------
-- Table structure for feedback
-- ----------------------------
DROP TABLE IF EXISTS `feedback`;
CREATE TABLE `feedback` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `create_time` bigint(20) NOT NULL,
  `feedback_advice` varchar(255) NOT NULL,
  `feedback_name` varchar(255) DEFAULT NULL,
  `last_modify_time` bigint(20) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of feedback
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for follow
-- ----------------------------
DROP TABLE IF EXISTS `follow`;
CREATE TABLE `follow` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `create_time` bigint(20) NOT NULL,
  `follow_id` bigint(20) NOT NULL,
  `last_modify_time` bigint(20) NOT NULL,
  `status` varchar(255) NOT NULL,
  `user_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of follow
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for hibernate_sequence
-- ----------------------------
DROP TABLE IF EXISTS `hibernate_sequence`;
CREATE TABLE `hibernate_sequence` (
  `next_val` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of hibernate_sequence
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for letter
-- ----------------------------
DROP TABLE IF EXISTS `letter`;
CREATE TABLE `letter` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `content` text NOT NULL,
  `create_time` bigint(20) NOT NULL,
  `pid` bigint(20) DEFAULT NULL,
  `receive_user_id` bigint(20) NOT NULL,
  `send_user_id` bigint(20) NOT NULL,
  `type` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of letter
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for look_record
-- ----------------------------
DROP TABLE IF EXISTS `look_record`;
CREATE TABLE `look_record` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `collect_id` bigint(20) NOT NULL,
  `create_time` bigint(20) NOT NULL,
  `last_modify_time` bigint(20) NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `is_delete` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of look_record
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for notice
-- ----------------------------
DROP TABLE IF EXISTS `notice`;
CREATE TABLE `notice` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `collect_id` varchar(255) DEFAULT NULL,
  `create_time` bigint(20) NOT NULL,
  `oper_id` varchar(255) DEFAULT NULL,
  `readed` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `user_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of notice
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for praise
-- ----------------------------
DROP TABLE IF EXISTS `praise`;
CREATE TABLE `praise` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `collect_id` bigint(20) NOT NULL,
  `create_time` bigint(20) NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `is_delete` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of praise
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for url_library
-- ----------------------------
DROP TABLE IF EXISTS `url_library`;
CREATE TABLE `url_library` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `count` int(11) DEFAULT '0',
  `logo_url` varchar(300) DEFAULT NULL,
  `url` varchar(600) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of url_library
-- ----------------------------
BEGIN;
INSERT INTO `url_library` VALUES (6, 0, 'https://the-x.cn/images/wxQRD.png', 'https://the-x.cn/cryptography/des.aspx');
INSERT INTO `url_library` VALUES (7, 0, 'https://img2018.cnblogs.com/blog/1645656/201906/1645656-20190625182037895-294392568.png', 'https://www.cnblogs.com/lwcode6/p/11084537.html');
INSERT INTO `url_library` VALUES (8, 0, 'http://127.0.0.1:8080/img/logo.jpg', 'https://www.cnblogs.com/cmt/p/14580194.html');
INSERT INTO `url_library` VALUES (9, 0, 'https://img-blog.csdnimg.cn/20201014180756930.png?x-oss-process=image/resize,m_fixed,h_64,w_64', 'https://blog.csdn.net/u011781521/article/details/77853571');
INSERT INTO `url_library` VALUES (10, 0, 'http://127.0.0.1:8080/img/logo.jpg', 'http://127.0.0.1:8080/');
INSERT INTO `url_library` VALUES (11, 0, 'https://img.kaikeba.com/a/34035142900202dvoz.png', 'https://www.kaikeba.com/');
COMMIT;

-- ----------------------------
-- Table structure for user
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `background_picture` varchar(255) DEFAULT NULL,
  `create_time` bigint(20) NOT NULL,
  `email` varchar(255) NOT NULL,
  `introduction` text,
  `last_modify_time` bigint(20) NOT NULL,
  `out_date` varchar(255) DEFAULT NULL,
  `pass_word` varchar(255) NOT NULL,
  `profile_picture` varchar(255) DEFAULT NULL,
  `user_name` varchar(255) NOT NULL,
  `validata_code` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UK_ob8kqyqqgmefl0aco34akdtpe` (`email`),
  UNIQUE KEY `UK_lqjrcobrh9jc8wpcar64q1bfh` (`user_name`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of user
-- ----------------------------
BEGIN;
INSERT INTO `user` VALUES (37, NULL, 1617006038513, '猪百万@163.com', NULL, 1617006038513, NULL, 'c09f76a432b72ca6a0aa0c5162f2e480', 'img/favicon.png', '百万大人', NULL);
INSERT INTO `user` VALUES (38, NULL, 1617013311049, 'Echo@163.com', NULL, 1617013311049, NULL, 'c09f76a432b72ca6a0aa0c5162f2e480', 'img/favicon.png', 'Echo', NULL);
INSERT INTO `user` VALUES (39, NULL, 1617093567966, 'Jzz8746@163.com', NULL, 1617093567966, NULL, '6a3990e7cddb2bf64265a1029e205446', 'img/favicon.png', 'Jzz', NULL);
INSERT INTO `user` VALUES (40, NULL, 1617099158251, 'zhumeimei@163.com', NULL, 1617099158251, NULL, '6a3990e7cddb2bf64265a1029e205446', 'img/favicon.png', '猪美美', NULL);
COMMIT;

-- ----------------------------
-- Table structure for user_is_follow
-- ----------------------------
DROP TABLE IF EXISTS `user_is_follow`;
CREATE TABLE `user_is_follow` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `is_follow` varchar(255) DEFAULT NULL,
  `profile_picture` varchar(255) DEFAULT NULL,
  `user_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of user_is_follow
-- ----------------------------
BEGIN;
COMMIT;

SET FOREIGN_KEY_CHECKS = 1;
